#Install Curl
sudo apt install curl gpg -y

#Install Microsoft package signing key for Ubuntu 22.04
curl https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.gpg
sudo install -o root -g root -m 644 microsoft.gpg /usr/share/keyrings/
sudo sh -c 'echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft.gpg] https://packages.microsoft.com/ubuntu/22.04/prod jammy main" > /etc/apt/sources.list.d/microsoft-ubuntu-jammy-prod.list'

#Install Microsoft Edge Browser
sudo install -o root -g root -m 644 microsoft.gpg /etc/apt/trusted.gpg.d/
sudo sh -c 'echo "deb [arch=amd64] https://packages.microsoft.com/repos/edge stable main" > /etc/apt/sources.list.d/microsoft-edge-stable.list'
sudo rm microsoft.gpg
sudo apt update && sudo apt install microsoft-edge-stable -y

#Install Microsoft Intune app
sudo apt install intune-portal -y

#Add the key for the 1Password apt repository:
curl -sS https://downloads.1password.com/linux/keys/1password.asc | sudo gpg --dearmor --output /usr/share/keyrings/1password-archive-keyring.gpg

#Add the 1Password apt repository:
echo 'deb [arch=amd64 signed-by=/usr/share/keyrings/1password-archive-keyring.gpg] https://downloads.1password.com/linux/debian/amd64 stable main' | sudo tee /etc/apt/sources.list.d/1password.list


#Add the debsig-verify policy:
sudo mkdir -p /etc/debsig/policies/AC2D62742012EA22/
curl -sS https://downloads.1password.com/linux/debian/debsig/1password.pol | sudo tee /etc/debsig/policies/AC2D62742012EA22/1password.pol
sudo mkdir -p /usr/share/debsig/keyrings/AC2D62742012EA22
curl -sS https://downloads.1password.com/linux/keys/1password.asc | sudo gpg --dearmor --output /usr/share/debsig/keyrings/AC2D62742012EA22/debsig.gpg


#Install 1Password:
sudo apt update && sudo apt install 1password -y

#Install NVDIA Driver
sudo apt purge nvidia* -y
sudo add-apt-repository ppa:graphics-drivers/ppa
sudo apt install nvidia-driver-455 -y

#Encrypt additional drive(Lines/drivename below can be modified if the 2nd drive name is different)
cat Encryption_key.txt | tr -d '\r\n' | sudo cryptsetup luksFormat --key-file=- /dev/nvme1n1
cat Encryption_key.txt | tr -d '\r\n' | sudo cryptsetup luksOpen --key-file=- /dev/nvme1n1 Drive2
sudo mkfs.ext4 -E root_owner=1000:1000  /dev/mapper/Drive2

#Install Defender
#Install Curl
sudo apt-get install curl -y

#Install libplist-utils
sudo apt-get install libplist-utils

#Add the repository for the distro and version
curl -o microsoft.list https://packages.microsoft.com/config/ubuntu/22.04/prod.list
sudo mv ./microsoft.list /etc/apt/sources.list.d/microsoft-prod.list

#Install gpg
sudo apt-get install gpg -y

#Install gnupg
sudo apt-get install gnupg -y

#Install the Microsoft GPG public key
curl -sSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null

#Install the HTTPS driver
sudo apt-get install apt-transport-https -y

#Update the repository metadata
sudo apt-get update -y

#Install MDATP Application
sudo apt-get install mdatp -y

#Install Defender onboarding script
sudo python3 MicrosoftDefenderATPOnboardingLinuxServer.py

#Update APT
sudo apt update -y
sudo apt-get dist-upgrade -y

#Verify device is now associated with org and reports org identifies
mdatp health --field org_id

#Check health status
mdatp health --field healthy

#Check if running the latest antimalware definitions
mdatp health --field definitions_status

#Check and enable real time protection
mdatp  health --field real_time_protection_enabled
sudo mdatp config real_time_protection --value enabled
sudo mdatp threat policy set --type potentially_unwanted_application --action block

#Test MDE for Linux using eicar test file
curl -o /tmp/eicar.com.txt https://www.eicar.org/download/eicar.com.txt
mdatp threat list

#Test EDR and simulate detection
curl -o MDELinuxDIY.zip https://mdatpclientanalyzer.blob.core.windows.net/mdatplinux/MDE%20Linux%20DIY.zip
unzip MDELinuxDIY.zip
./mde_linux_edr_diy.sh

#Remove downloaded EDR files
rm MDELinuxDIY.zip
rm mde_linux_edr_diy.sh


sudo shutdown -r now
