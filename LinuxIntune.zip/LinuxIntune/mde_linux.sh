sudo apt-get install curl
sudo apt-get install libplist-utils
curl -o microsoft.list https://packages.microsoft.com/config/ubuntu/22.04/prod.list
sudo mv ./microsoft.list /etc/apt/sources.list.d/microsoft-prod.list
sudo apt-get install gpg
sudo apt-get install gnupg
curl -sSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null
sudo apt-get install apt-transport-https
sudo apt-get update
sudo apt-get install mdatp
sudo python3 MicrosoftDefenderATPOnboardingLinuxServer.py