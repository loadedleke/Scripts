#Install Curl
sudo apt-get install curl

#Install libplist-utils
sudo apt-get install libplist-utils

#Add the repository for the distro and version
curl -o microsoft.list https://packages.microsoft.com/config/ubuntu/20.04/prod.list
sudo mv ./microsoft.list /etc/apt/sources.list.d/microsoft-prod.list

#Install gpg
sudo apt-get install gpg

#Install gnupg
sudo apt-get install gnupg

#Install the Microsoft GPG public key
curl -sSL https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor | sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null

#Install the HTTPS driver
sudo apt-get install apt-transport-https

#Update the repository metadata
sudo apt-get update

#Install MDATP Application
sudo apt-get install mdatp

#Install Defender onboarding script
sudo python3 MicrosoftDefenderATPOnboardingLinuxServer.py
